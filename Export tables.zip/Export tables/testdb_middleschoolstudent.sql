-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: testdb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `middleschoolstudent`
--

DROP TABLE IF EXISTS `middleschoolstudent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `middleschoolstudent` (
  `MidSchoolID` int NOT NULL AUTO_INCREMENT,
  `StudentEmail` varchar(100) DEFAULT NULL,
  `Passwd` varchar(100) DEFAULT NULL,
  `Race` varchar(30) DEFAULT NULL,
  `Gender` char(7) DEFAULT NULL,
  `FName` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Assitancerequired` char(5) DEFAULT NULL,
  `SchoolName` varchar(100) DEFAULT NULL,
  `city` varchar(60) DEFAULT NULL,
  `Likes` varchar(100) DEFAULT NULL,
  `ENdrosement` varchar(80) DEFAULT NULL,
  `Eid` int DEFAULT NULL,
  `CareerCluster` varchar(1000) DEFAULT NULL,
  `cid` int DEFAULT NULL,
  `Middleschoolid` int DEFAULT NULL,
  PRIMARY KEY (`MidSchoolID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `middleschoolstudent`
--

LOCK TABLES `middleschoolstudent` WRITE;
/*!40000 ALTER TABLE `middleschoolstudent` DISABLE KEYS */;
INSERT INTO `middleschoolstudent` VALUES (1,'gmail','0','asian','m','abc','yahoo','0','psbb','denton','teaching','PS',NULL,'TEacher',NULL,NULL),(2,'np@sanger.ws',NULL,'asian','m','Nikhil','nkhere@gmail.com','yes','walker middle school','denton','law enforcement','PS',NULL,'police',NULL,NULL),(3,'jade@wms.ws',NULL,'american','m','Jade','jadeiscool@gmail.com','yes','walker middle school','denton','STEM','STEM',NULL,'Engineer',NULL,NULL),(4,'srimathi@denton.ws',NULL,'asian','m','Sri Mathi','Sri1907@gmail.com','yes','Denton middle school','denton','Finance','B&I',NULL,'Finance',NULL,NULL),(5,'srimathi@denton.ws',NULL,'asian','f','Sri Mathi','Sri1907@gmail.com','yes','Denton middle school','denton','Finance','B&I',NULL,'Finance',NULL,NULL);
/*!40000 ALTER TABLE `middleschoolstudent` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-25 16:37:34
