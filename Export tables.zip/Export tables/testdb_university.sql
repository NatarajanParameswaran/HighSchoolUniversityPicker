-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: testdb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `university`
--

DROP TABLE IF EXISTS `university`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `university` (
  `univID` int NOT NULL,
  `UnivName` varchar(100) DEFAULT NULL,
  `Urank` int DEFAULT NULL,
  `univpreq` varchar(100) DEFAULT NULL,
  `Univaddr` int DEFAULT NULL,
  `MajorID` int DEFAULT NULL,
  `CourseName` varchar(70) DEFAULT NULL,
  `Ischolarship` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`univID`),
  KEY `MajorID` (`MajorID`),
  KEY `Univaddr` (`Univaddr`),
  CONSTRAINT `university_ibfk_1` FOREIGN KEY (`MajorID`) REFERENCES `major` (`majorID`),
  CONSTRAINT `university_ibfk_2` FOREIGN KEY (`Univaddr`) REFERENCES `univcontact` (`univID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `university`
--

LOCK TABLES `university` WRITE;
/*!40000 ALTER TABLE `university` DISABLE KEYS */;
INSERT INTO `university` VALUES (1,'UNT',243,'SAT score above 1000',1,1,'CSC','1'),(2,'UNT',243,'SAT score above 900',1,2,'physcology','1'),(3,'UNT',243,'SAT score above 1000',1,5,'MBA','1'),(4,'UT dallas',200,'SAT score above 1100',2,1,'CSC','1'),(5,'UT dallas',200,'SAT score above 1000',2,2,'health science','1'),(6,'Sunny Buffalo',290,'SAT score above 900',3,4,'bachelors ARts','1'),(7,'Arizona state',108,'SAT score above 1100',4,1,'CS','1'),(8,'Arizona state',108,'SAT score above 1000',4,5,'MBA','1'),(9,'Arizona State',108,'SAT score above 950',4,2,'MBBS','1'),(10,'Arizona State',108,'SAT score above 900',4,1,'Electrical engineering','1');
/*!40000 ALTER TABLE `university` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-25 16:37:29
